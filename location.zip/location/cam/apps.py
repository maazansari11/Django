from django.apps import AppConfig


class CamConfig(AppConfig):
    name = 'cam'
